﻿# Spotify Control Track Transition Single-Hook Isolation v0.4.0
# Standalone Phase-2 profiler. Does not install/replace Spotify Control production files.
[CmdletBinding()]
param(
    [ValidateSet("Run","Status","SelfTest")]
    [string]$Action = "Run",
    [int]$PlaybackWarmupSeconds = 20,
    [int]$TransitionSeconds = 90,
    [int]$SampleIntervalMs = 250,
    [int]$TransitionWindowSeconds = 6
)

$ErrorActionPreference = "Stop"
$Version = "0.4.0"
$AcceptedMainShas = @("5ff7990564287bc409626d8835e27679fb8de434868443313be42fdc0d9cce3b","27783abc40c446aadf6f2a9373b4525ada89759075f37e934958c8e449f2d98f")
$ExpectedAddonSha = "b7d1a4bc7707533400402fe42e60d724f88656c2477d4d4a5c0f47be60f47977"
$ExpectedAgentSha = "2a4f6f02103ef9d4594e9fe4ac23fd4d94d4553902d6ddaf5fc3e10bebd56278"
$ExpectedBootstrapSha = "d9b28007eb95874f02c48ed50d8ada71134e15e6492fef0e2d45dd2522053fe6"
$ExpectedSpotifyVersion = "1.3.6.1921"
$ExpectedSpicetifyVersion = "2.46.2"

$Root = Join-Path $env:LOCALAPPDATA "SpotifyControl"
$Bin = Join-Path $Root "bin"
$BootstrapDir = Join-Path $Root "bootstrap"
$Reports = Join-Path $Root "reports"
$LogRoot = Join-Path $Root "logs"
$BackupRoot = Join-Path $Root "backups\performance-phase2-single-hook-v040"
$ConfigPath = Join-Path $env:APPDATA "spicetify\config-xpui.ini"
$SpotifyExe = Join-Path $env:APPDATA "Spotify\Spotify.exe"
$SpotifyRoot = Split-Path -Parent $SpotifyExe
$XpuiRoot = Join-Path $SpotifyRoot "Apps\xpui"
$IndexPath = Join-Path $XpuiRoot "index.html"
$LocalSpotify = Join-Path $env:LOCALAPPDATA "Spotify"
$MainPath = Join-Path $Bin "spotify-control.ps1"
$AddonPath = Join-Path $Bin "addon-manager.ps1"
$AgentPath = Join-Path $Bin "spotify-control-agent.vbs"
$BootstrapPath = Join-Path $BootstrapDir "spotify-control-self-updater.ps1"
$ResidentTaskName = "SpotifyControl Resident Agent"
$LatestJson = Join-Path $Reports "track-transition-single-hook-latest.json"
$LatestTxt = Join-Path $Reports "track-transition-single-hook-latest.txt"
$LatestCsv = Join-Path $Reports "track-transition-single-hook-raw-latest.csv"

$DirectExtensionAllowlist = @("bookmark.js","loopyLoop.js","popupLyrics.js","shuffle+.js")
$AdditionalSafeExtensionAllowlist = @("sc-cover-ambience.js","sc-star-ratings.js","sc-volume-percentage.js")
$OptionalPithayaAllowlist = @("better-local-files","eternal-jukebox","playlist-maker")
$ProtectedAppNames = @("ivLyrics","tagify","splitify")
$NextOffsets = @(15,30,45,60,75)

if($Action -ne "SelfTest"){New-Item -ItemType Directory -Force -Path $Reports,$LogRoot,$BackupRoot | Out-Null}
$Log = Join-Path $LogRoot ("track-transition-single-hook-{0}.log" -f (Get-Date -Format "yyyy-MM-dd"))

$script:Session = $null
$script:OriginalConfigHash = $null
$script:OriginalExtensions = @()
$script:OriginalApps = @()
$script:OriginalIndexBackup = $null
$script:OriginalIndexHash = $null
$script:OriginalXpuiTree = $null
$script:XpuiMutationStarted = $false
$script:XpuiRestored = $false
$script:HookInventory = $null
$script:ResidentWasRunning = $false
$script:ResidentSuspended = $false
$script:PersistenceBackup = $null
$script:RoleCacheSignature = ""
$script:RoleCache = @{}

function Write-LabLog {
    param([string]$Message,[ValidateSet("INFO","WARN","ERROR","OK")][string]$Level="INFO")
    $line = "{0} [{1}] {2}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"),$Level,$Message
    if($Action -ne "SelfTest"){Add-Content -LiteralPath $Log -Value $line -Encoding UTF8}
    switch($Level){
        "ERROR"{Write-Host $line -ForegroundColor Red}
        "WARN"{Write-Host $line -ForegroundColor Yellow}
        "OK"{Write-Host $line -ForegroundColor Green}
        default{Write-Host $line}
    }
}

function Test-SafePath {
    param([AllowNull()][AllowEmptyString()][string]$Path,[string]$Type="Any")
    if([string]::IsNullOrWhiteSpace($Path)){return $false}
    try{
        if($Type -eq "Leaf"){return [bool](Test-Path -LiteralPath $Path -PathType Leaf -ErrorAction SilentlyContinue)}
        if($Type -eq "Container"){return [bool](Test-Path -LiteralPath $Path -PathType Container -ErrorAction SilentlyContinue)}
        return [bool](Test-Path -LiteralPath $Path -ErrorAction SilentlyContinue)
    }catch{return $false}
}

function Get-Sha256Lower {
    param([string]$Path)
    return ((Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToLowerInvariant())
}

function ConvertTo-NativeQuotedArgument {
    param([AllowEmptyString()][string]$Value)
    if($null -eq $Value -or $Value.Length -eq 0){return '""'}
    if($Value -notmatch '[\s"]'){return $Value}
    $sb=New-Object System.Text.StringBuilder
    [void]$sb.Append('"')
    $slashes=0
    foreach($ch in $Value.ToCharArray()){
        if($ch -eq '\'){$slashes++;continue}
        if($ch -eq '"'){
            if($slashes -gt 0){[void]$sb.Append(('\'*($slashes*2)))}
            [void]$sb.Append('\"');$slashes=0;continue
        }
        if($slashes -gt 0){[void]$sb.Append(('\'*$slashes));$slashes=0}
        [void]$sb.Append($ch)
    }
    if($slashes -gt 0){[void]$sb.Append(('\'*($slashes*2)))}
    [void]$sb.Append('"')
    return $sb.ToString()
}

function Invoke-Native {
    param([Parameter(Mandatory=$true)][string]$FilePath,[string[]]$Arguments=@(),[int]$TimeoutSeconds=900)
    $psi=New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName=$FilePath;$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true
    $psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true
    $psi.Arguments=(($Arguments|ForEach-Object{ConvertTo-NativeQuotedArgument ([string]$_)}) -join " ")
    $proc=New-Object System.Diagnostics.Process;$proc.StartInfo=$psi
    try{
        if(-not $proc.Start()){throw "Could not start process: $FilePath"}
        $outTask=$proc.StandardOutput.ReadToEndAsync();$errTask=$proc.StandardError.ReadToEndAsync()
        if(-not $proc.WaitForExit($TimeoutSeconds*1000)){try{$proc.Kill()}catch{};throw "Process timed out: $FilePath"}
        $parts=@();$stdout=$outTask.Result;$stderr=$errTask.Result
        if(-not [string]::IsNullOrWhiteSpace($stdout)){$parts += $stdout.Trim()}
        if(-not [string]::IsNullOrWhiteSpace($stderr)){$parts += $stderr.Trim()}
        return [pscustomobject]@{ExitCode=$proc.ExitCode;Output=($parts -join [Environment]::NewLine)}
    }finally{$proc.Dispose()}
}

function Get-SpicetifyExe {
    $cmd=Get-Command spicetify -ErrorAction SilentlyContinue
    if(-not $cmd){throw "spicetify is not available on PATH."}
    return $cmd.Source
}

function Get-IniValue {
    param([string]$Path,[string]$Section,[string]$Key)
    $inside=$false
    foreach($line in @(Get-Content -LiteralPath $Path -ErrorAction Stop)){
        $t=$line.Trim()
        if($t -match '^\[(.+)\]$'){$inside=([string]$Matches[1] -eq $Section);continue}
        if($inside -and $t -match '^([^=]+?)\s*=\s*(.*)$'){
            if(([string]$Matches[1]).Trim() -eq $Key){return ([string]$Matches[2]).Trim()}
        }
    }
    return $null
}

function Get-IniList {
    param([string]$Path,[string]$Section,[string]$Key)
    $raw=Get-IniValue -Path $Path -Section $Section -Key $Key
    if([string]::IsNullOrWhiteSpace([string]$raw)){return @()}
    return @(([string]$raw -split '\|')|ForEach-Object{$_.Trim()}|Where-Object{-not [string]::IsNullOrWhiteSpace($_)})
}

function Get-TreeFingerprint {
    param([string]$RootPath)
    if(-not(Test-SafePath $RootPath "Container")){throw "Tree root missing: $RootPath"}
    $rows=New-Object System.Collections.Generic.List[string]
    $files=@(Get-ChildItem -LiteralPath $RootPath -File -Recurse -Force -ErrorAction Stop|Sort-Object FullName)
    [int64]$total=0
    foreach($f in $files){
        $rel=$f.FullName.Substring($RootPath.Length).TrimStart('\').Replace('\','/')
        $h=Get-Sha256Lower $f.FullName;$total += [int64]$f.Length
        $rows.Add(("{0}|{1}|{2}" -f $rel,[int64]$f.Length,$h))
    }
    $text=($rows -join "`n")+"`n";$enc=[Text.UTF8Encoding]::new($false);$sha=[Security.Cryptography.SHA256]::Create()
    try{$hash=([BitConverter]::ToString($sha.ComputeHash($enc.GetBytes($text))).Replace('-','').ToLowerInvariant())}finally{$sha.Dispose()}
    return [pscustomobject]@{sha256=$hash;file_count=$files.Count;total_bytes=$total}
}

function ConvertFrom-Utf8BytesStrict {
    param([byte[]]$Bytes)
    $bom=($Bytes.Length -ge 3 -and $Bytes[0]-eq 0xEF -and $Bytes[1]-eq 0xBB -and $Bytes[2]-eq 0xBF)
    $offset=0;if($bom){$offset=3}
    $enc=[Text.UTF8Encoding]::new($false,$true)
    $text=$enc.GetString($Bytes,$offset,$Bytes.Length-$offset)
    return [pscustomobject]@{text=$text;bom=$bom}
}

function ConvertTo-Utf8BytesPreserveBom {
    param([string]$Text,[bool]$Bom)
    $body=[Text.UTF8Encoding]::new($false).GetBytes($Text)
    if(-not $Bom){return $body}
    $pre=[byte[]](0xEF,0xBB,0xBF);$out=New-Object byte[] ($pre.Length+$body.Length);[Array]::Copy($pre,0,$out,0,3);[Array]::Copy($body,0,$out,3,$body.Length);return $out
}

function Get-IndexHookInventoryFromBytes {
    param([byte[]]$Bytes,[string[]]$ConfiguredExtensions,[string[]]$ConfiguredApps)
    $decoded=ConvertFrom-Utf8BytesStrict $Bytes;$text=[string]$decoded.text
    $scripts=New-Object System.Collections.Generic.List[object]
    $pattern='(?is)<script\b[^>]*\bsrc\s*=\s*(["''])(?<src>[^"'']+)\1[^>]*>\s*</script>'
    foreach($m in [regex]::Matches($text,$pattern)){
        $src=([string]$m.Groups['src'].Value).TrimStart('/').Replace('\\','/')
        if($src -notmatch '(?i)^extensions/'){continue}
        $rest=$src.Substring('extensions/'.Length);$parts=@($rest -split '/')
        $kind='unknown';$owner=''
        if($parts.Count -eq 1){
            if($parts[0] -eq 'theme.js'){$kind='theme';$owner='theme'}
            else{$kind='direct';$owner=[IO.Path]::GetFileName($parts[0])}
        }else{$kind='app-hook';$owner=$parts[0]}
        $scripts.Add([pscustomobject]@{tag=$m.Value;src=$src;kind=$kind;owner=$owner})
    }
    $styles=New-Object System.Collections.Generic.List[object]
    $linkPattern='(?is)<link\b[^>]*>'
    foreach($m in [regex]::Matches($text,$linkPattern)){
        $tag=$m.Value
        if($tag -match '(?i)class\s*=\s*(["''])[^"'']*\buserCSS\b[^"'']*\1' -and $tag -match '(?i)href\s*=\s*(["''])(?<href>colors\.css|user\.css)\1'){$styles.Add([pscustomobject]@{tag=$tag;href=[string]$Matches['href']})}
    }
    return [pscustomobject]@{bom=[bool]$decoded.bom;scripts=$scripts.ToArray();styles=$styles.ToArray();configured_extensions=@($ConfiguredExtensions);configured_apps=@($ConfiguredApps)}
}

function ConvertTo-VariantToken {
    param([AllowNull()][AllowEmptyString()][string]$Value)
    $t=([string]$Value -replace '(?i)\.js$','' -replace '[^A-Za-z0-9]+','_').Trim('_').ToUpperInvariant()
    if([string]::IsNullOrWhiteSpace($t)){return 'HOOK'}
    return $t
}

function Build-SingleHookVariantMatrix {
    param($Inventory,[string[]]$Extensions,[string[]]$Apps)
    $safeDirectTargets=@($Extensions|Where-Object{($DirectExtensionAllowlist+$AdditionalSafeExtensionAllowlist) -contains ([IO.Path]::GetFileName($_))})
    $optionalApps=@($Apps|Where-Object{$OptionalPithayaAllowlist -contains $_})
    $marketApps=@($Apps|Where-Object{$_ -eq 'marketplace'})
    $knownApps=@($optionalApps+$marketApps|Select-Object -Unique)
    foreach($p in $ProtectedAppNames){if($knownApps -contains $p){throw "Internal protected-app allowlist violation: $p"}}

    $safeDirectHooks=@($Inventory.scripts|Where-Object{$_.kind -eq 'direct' -and $safeDirectTargets -contains $_.owner})
    $optionalHooks=@($Inventory.scripts|Where-Object{$_.kind -eq 'app-hook' -and $optionalApps -contains $_.owner})
    $marketHooks=@($Inventory.scripts|Where-Object{$_.kind -eq 'app-hook' -and $marketApps -contains $_.owner})
    $knownScriptHooks=@($safeDirectHooks+$optionalHooks+$marketHooks|Select-Object -Unique -Property tag,src,kind,owner)
    $themeHooks=@($Inventory.scripts|Where-Object{$_.kind -eq 'theme'})
    $cssHooks=@($Inventory.styles)
    $protectedOrUnknown=@($Inventory.scripts|Where-Object{
        if($_.kind -eq 'theme'){return $false}
        if($knownScriptHooks.src -contains $_.src){return $false}
        return $true
    })

    $variants=New-Object System.Collections.Generic.List[object]
    $variants.Add([pscustomobject]@{label='BASELINE_A';remove_tags=@();definition='Original applied xpui index; no hooks removed.';category='baseline';target_src=$null;target_kind=$null;target_owner=$null})
    $seen=@{}
    foreach($h in @($knownScriptHooks)){
        $prefix=if($h.kind -eq 'direct'){'DIRECT'}else{'APP'}
        $base='SINGLE_{0}_{1}_OFF' -f $prefix,(ConvertTo-VariantToken ([string]$h.owner))
        if(-not $seen.ContainsKey($base)){$seen[$base]=0};$seen[$base]++
        $label=if([int]$seen[$base] -eq 1){$base}else{"${base}_$($seen[$base])"}
        $variants.Add([pscustomobject]@{label=$label;remove_tags=@([string]$h.tag);definition=('Disable exactly one allowlisted safe script hook: '+[string]$h.src);category='single-script';target_src=[string]$h.src;target_kind=[string]$h.kind;target_owner=[string]$h.owner})
    }
    foreach($h in @($themeHooks)){
        $base='SINGLE_THEME_JS_OFF';if(-not $seen.ContainsKey($base)){$seen[$base]=0};$seen[$base]++
        $label=if([int]$seen[$base] -eq 1){$base}else{"${base}_$($seen[$base])"}
        $variants.Add([pscustomobject]@{label=$label;remove_tags=@([string]$h.tag);definition=('Disable exactly one theme.js script tag: '+[string]$h.src);category='single-theme';target_src=[string]$h.src;target_kind='theme';target_owner='theme'})
    }
    foreach($h in @($cssHooks)){
        $base='SINGLE_USERCSS_{0}_OFF' -f (ConvertTo-VariantToken ([string]$h.href));if(-not $seen.ContainsKey($base)){$seen[$base]=0};$seen[$base]++
        $label=if([int]$seen[$base] -eq 1){$base}else{"${base}_$($seen[$base])"}
        $variants.Add([pscustomobject]@{label=$label;remove_tags=@([string]$h.tag);definition=('Disable exactly one userCSS link tag: '+[string]$h.href);category='single-usercss';target_src=[string]$h.href;target_kind='usercss';target_owner=[string]$h.href})
    }
    $presentationTags=@($themeHooks.tag+$cssHooks.tag)
    if($presentationTags.Count -gt 1){
        $variants.Add([pscustomobject]@{label='PRESENTATION_HOOKS_OFF';remove_tags=$presentationTags;definition='Disable theme.js and userCSS link tags together to measure presentation-hook interaction only; Spicetify core/preprocesses remain.';category='presentation-combined';target_src=$null;target_kind='presentation';target_owner='theme+userCSS'})
    }
    $variants.Add([pscustomobject]@{label='BASELINE_B';remove_tags=@();definition='Original applied xpui index restored exactly; no hooks removed.';category='baseline';target_src=$null;target_kind=$null;target_owner=$null})
    return [pscustomobject]@{variants=$variants.ToArray();known_script_hooks=@($knownScriptHooks|ForEach-Object{$_.src});protected_or_unknown_hooks=@($protectedOrUnknown|ForEach-Object{$_.src});presentation_tag_count=$presentationTags.Count}
}

function Write-IndexVariantAtomic {
    param($Variant)
    if(-not(Test-SafePath $script:OriginalIndexBackup 'Leaf')){throw 'Original xpui index backup is missing.'}
    $original=[IO.File]::ReadAllBytes($script:OriginalIndexBackup);$decoded=ConvertFrom-Utf8BytesStrict $original;$text=[string]$decoded.text
    $removed=New-Object System.Collections.Generic.List[string]
    foreach($tag in @($Variant.remove_tags)){
        if([string]::IsNullOrWhiteSpace([string]$tag)){continue}
        $count=([regex]::Matches($text,[regex]::Escape([string]$tag))).Count
        if($count -ne 1){throw "Variant $($Variant.label) expected one exact hook tag, found $count."}
        $text=$text.Replace([string]$tag,'');$removed.Add([string]$tag)
    }
    $bytes=ConvertTo-Utf8BytesPreserveBom -Text $text -Bom ([bool]$decoded.bom)
    $tmp=$IndexPath+'.spotifycontrol-perf-new-'+[Guid]::NewGuid().ToString('N');$old=$IndexPath+'.spotifycontrol-perf-old-'+[Guid]::NewGuid().ToString('N')
    try{
        [IO.File]::WriteAllBytes($tmp,$bytes)
        [IO.File]::Replace($tmp,$IndexPath,$old,$true)
        if((Get-Sha256Lower $old) -ne $script:OriginalIndexHash){throw 'Same-volume index swap backup did not match the original index.'}
    }finally{Remove-Item -LiteralPath $tmp,$old -Force -ErrorAction SilentlyContinue}
    $script:XpuiMutationStarted=$true
    return [pscustomobject]@{removed_count=$removed.Count;index_sha256=(Get-Sha256Lower $IndexPath)}
}

function Restore-OriginalXpui {
    if($script:XpuiRestored){return}
    if(-not(Test-SafePath $script:OriginalIndexBackup 'Leaf')){throw 'Original xpui index backup is missing.'}
    [IO.File]::WriteAllBytes($IndexPath,[IO.File]::ReadAllBytes($script:OriginalIndexBackup))
    if((Get-Sha256Lower $IndexPath) -ne $script:OriginalIndexHash){throw 'Original xpui index did not restore byte-for-byte.'}
    $tree=Get-TreeFingerprint $XpuiRoot
    if($tree.sha256 -ne $script:OriginalXpuiTree.sha256 -or $tree.file_count -ne $script:OriginalXpuiTree.file_count -or $tree.total_bytes -ne $script:OriginalXpuiTree.total_bytes){throw 'Active xpui tree did not restore exactly.'}
    if((Get-Sha256Lower $ConfigPath) -ne $script:OriginalConfigHash){throw 'Spicetify config changed even though this profiler is read-only for config.'}
    $script:XpuiRestored=$true
    Write-LabLog "Original active xpui index and full tree restored exactly; Spicetify config remained unchanged." 'OK'
}

function Stop-SpotifyForVariant {
    $procs=@(Get-Process Spotify -ErrorAction SilentlyContinue);if($procs.Count -eq 0){return}
    foreach($p in @($procs|Where-Object{$_.MainWindowHandle -ne 0})){try{[void]$p.CloseMainWindow()}catch{}}
    for($i=0;$i -lt 30;$i++){if(@(Get-Process Spotify -ErrorAction SilentlyContinue).Count -eq 0){return};Start-Sleep -Milliseconds 250}
    Write-LabLog 'Spotify did not exit through its main window; using process termination only after playback was paused.' 'WARN'
    @(Get-Process Spotify -ErrorAction SilentlyContinue)|Stop-Process -Force -ErrorAction SilentlyContinue
    for($i=0;$i -lt 40;$i++){if(@(Get-Process Spotify -ErrorAction SilentlyContinue).Count -eq 0){return};Start-Sleep -Milliseconds 250}
    throw 'Spotify did not exit before xpui variant swap.'
}

function Prepare-Variant {
    param($Variant)
    Stop-SpotifyForVariant
    if($script:XpuiMutationStarted){[IO.File]::WriteAllBytes($IndexPath,[IO.File]::ReadAllBytes($script:OriginalIndexBackup));if((Get-Sha256Lower $IndexPath)-ne $script:OriginalIndexHash){throw 'Could not reset index to original before next variant.'}}
    $mutation=Write-IndexVariantAtomic $Variant
    if(-not(Test-SafePath $SpotifyExe 'Leaf')){throw 'Spotify executable disappeared before variant launch.'}
    Start-Process -FilePath $SpotifyExe
    if(-not(Wait-SpotifyReady 45)){throw "Spotify did not become healthy for $($Variant.label)"}
    $script:RoleCacheSignature='';$script:RoleCache=@{}
    Start-Sleep -Seconds 3;Send-MediaKey 'PlayPause'
    Write-LabLog ("Playback start key sent for {0}; removed_hooks={1}; warmup={2} sec." -f $Variant.label,$mutation.removed_count,$PlaybackWarmupSeconds)
    Start-Sleep -Seconds $PlaybackWarmupSeconds
    return $mutation
}

function Get-Median {
    param([double[]]$Values)
    if($null -eq $Values -or $Values.Count -eq 0){return 0.0}
    $s=@($Values|Sort-Object);$n=$s.Count
    if(($n%2)-eq 1){return [double]$s[[int][Math]::Floor($n/2)]}
    return ([double]$s[$n/2-1]+[double]$s[$n/2])/2.0
}

function Get-Percentile {
    param([double[]]$Values,[double]$P)
    if($null -eq $Values -or $Values.Count -eq 0){return 0.0}
    $s=@($Values|Sort-Object)
    if($s.Count -eq 1){return [double]$s[0]}
    $index=[Math]::Ceiling(($P/100.0)*$s.Count)-1
    if($index -lt 0){$index=0};if($index -ge $s.Count){$index=$s.Count-1}
    return [double]$s[$index]
}

function Get-LogicalCpuCount {
    try{$cpu=Get-CimInstance Win32_Processor|Select-Object -First 1;return [Math]::Max(1,[int]$cpu.NumberOfLogicalProcessors)}
    catch{return [Math]::Max(1,[Environment]::ProcessorCount)}
}

function Get-ProcessRoleFromCommandLine {
    param([AllowNull()][string]$CommandLine)
    if([string]::IsNullOrWhiteSpace($CommandLine)){return "unknown"}
    if($CommandLine -match '--type=renderer(?:\s|$)'){return "renderer"}
    if($CommandLine -match '--type=gpu-process(?:\s|$)'){return "gpu"}
    if($CommandLine -match '--type=utility(?:\s|$)'){return "utility"}
    if($CommandLine -notmatch '--type='){return "main"}
    return "other"
}

function Get-SpotifyPidSet {
    return @(Get-Process Spotify -ErrorAction SilentlyContinue|Select-Object -ExpandProperty Id|Sort-Object)
}

function Update-RoleCache {
    param([int[]]$Pids)
    $sig=(@($Pids|Sort-Object)-join ',')
    if($sig -eq $script:RoleCacheSignature){return}
    $map=@{}
    foreach($procId in $Pids){
        $cmd=$null
        try{$cmd=(Get-CimInstance Win32_Process -Filter "ProcessId=$procId" -ErrorAction Stop).CommandLine}catch{}
        $map[[int]$procId]=Get-ProcessRoleFromCommandLine $cmd
    }
    $script:RoleCache=$map;$script:RoleCacheSignature=$sig
}

function Wait-SpotifyReady {
    param([int]$TimeoutSeconds=45)
    for($i=0;$i -lt $TimeoutSeconds;$i++){
        if(@(Get-Process Spotify -ErrorAction SilentlyContinue).Count -ge 3){return $true}
        Start-Sleep -Seconds 1
    }
    return $false
}

function Wait-SpotifyRestartStable {
    param([int[]]$BeforePids=@(),[int]$TimeoutSeconds=90)
    $changed=$false;$stable=0;$last="";$before=(@($BeforePids|Sort-Object)-join ',')
    for($i=0;$i -lt $TimeoutSeconds;$i++){
        Start-Sleep -Seconds 1;$pids=@(Get-SpotifyPidSet)
        if($pids.Count -lt 3){$stable=0;continue}
        $sig=($pids -join ',');if($sig -ne $before){$changed=$true}
        if($sig -eq $last){$stable++}else{$stable=1;$last=$sig}
        if($changed -and $stable -ge 4){Write-LabLog "Spotify restart stabilized: pids=$sig";return $true}
    }
    return (Wait-SpotifyReady 15)
}

function Copy-Tree {
    param([string]$Source,[string]$Destination)
    if(-not (Test-SafePath $Source "Container")){return $false}
    New-Item -ItemType Directory -Force -Path $Destination | Out-Null
    $robocopy=Join-Path $env:SystemRoot "System32\robocopy.exe"
    $r=Invoke-Native -FilePath $robocopy -Arguments @($Source,$Destination,"/E","/COPY:DAT","/DCOPY:DAT","/R:2","/W:1","/XJ","/NP","/NFL","/NDL") -TimeoutSeconds 1800
    if($r.ExitCode -gt 7){throw "Robocopy failed ($($r.ExitCode)): $Source -> $Destination"}
    return $true
}

function Backup-ProtectedPersistence {
    param([string]$Destination)
    New-Item -ItemType Directory -Force -Path $Destination | Out-Null
    $sources=New-Object System.Collections.Generic.List[string]
    foreach($profile in @("Browser","Default")){
        foreach($storage in @("IndexedDB","Local Storage","Session Storage")){
            $src=Join-Path (Join-Path $LocalSpotify $profile) $storage
            if(Test-SafePath $src "Container"){
                $dst=Join-Path (Join-Path $Destination $profile) $storage
                if(Copy-Tree $src $dst){$sources.Add($src)}
            }
        }
        if($profile -eq "Browser"){
            $web=Join-Path (Join-Path $LocalSpotify $profile) "WebStorage"
            if(Test-SafePath $web "Container"){
                $dst=Join-Path (Join-Path $Destination $profile) "WebStorage"
                if(Copy-Tree $web $dst){$sources.Add($web)}
            }
        }
        $pref=Join-Path (Join-Path $LocalSpotify $profile) "Preferences"
        if(Test-SafePath $pref "Leaf"){
            $pd=Join-Path $Destination $profile;New-Item -ItemType Directory -Force -Path $pd|Out-Null
            Copy-Item -LiteralPath $pref -Destination (Join-Path $pd "Preferences") -Force;$sources.Add($pref)
        }
    }
    Copy-Item -LiteralPath $ConfigPath -Destination (Join-Path $Destination "config-xpui.ini") -Force
    $sources.Add($ConfigPath)
    if($sources.Count -lt 3){throw "Protected persistence backup was unexpectedly incomplete; refusing profiling mutation."}
    $m=[pscustomobject]@{created_at=(Get-Date).ToString("o");version=$Version;sources=$sources.ToArray();purpose="Safety copy only; profiler never writes Spotify WebView persistence stores."}
    $m|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $Destination "backup-manifest.json") -Encoding UTF8
    Write-LabLog "Protected persistence safety backup created: $Destination" "OK"
    return $Destination
}

function Get-ResidentProcesses {
    $rows=@()
    try{$rows=@(Get-CimInstance Win32_Process -Filter "Name='wscript.exe'" -ErrorAction Stop)}catch{return @()}
    return @($rows|Where-Object{$null -ne $_.CommandLine -and $_.CommandLine.IndexOf($AgentPath,[System.StringComparison]::OrdinalIgnoreCase) -ge 0})
}

function Wait-ControlWorkersIdle {
    param([int]$TimeoutSeconds=30)
    for($i=0;$i -lt $TimeoutSeconds;$i++){
        $busy=@()
        try{$busy=@(Get-CimInstance Win32_Process -ErrorAction Stop|Where-Object{$_.Name -match '^powershell(?:\.exe)?$' -and $null -ne $_.CommandLine -and $_.CommandLine.IndexOf($MainPath,[System.StringComparison]::OrdinalIgnoreCase) -ge 0})}catch{}
        if($busy.Count -eq 0){return $true}
        Start-Sleep -Seconds 1
    }
    return $false
}

function Suspend-Resident {
    $res=@(Get-ResidentProcesses)
    if($res.Count -ne 1){throw "Accepted runtime expects exactly one resident before profiling; found $($res.Count). No mutation was started."}
    $script:ResidentWasRunning=$true
    Stop-Process -Id ([int]$res[0].ProcessId) -Force -ErrorAction Stop
    for($i=0;$i -lt 20;$i++){if(@(Get-ResidentProcesses).Count -eq 0){$script:ResidentSuspended=$true;Write-LabLog "Resident temporarily suspended for uncontaminated profiling." "OK";return};Start-Sleep -Milliseconds 250}
    throw "Could not suspend Spotify Control resident cleanly."
}

function Restore-Resident {
    if(-not $script:ResidentWasRunning){return}
    $existing=@(Get-ResidentProcesses)
    if($existing.Count -gt 0){foreach($p in $existing){try{Stop-Process -Id ([int]$p.ProcessId) -Force -ErrorAction SilentlyContinue}catch{}};Start-Sleep -Seconds 1}
    $started=$false
    try{Start-ScheduledTask -TaskName $ResidentTaskName -ErrorAction Stop;$started=$true}catch{}
    if(-not $started){
        $wscript=Join-Path $env:SystemRoot "System32\wscript.exe"
        Start-Process -FilePath $wscript -ArgumentList @("//B","//NoLogo",('"'+$AgentPath+'"')) -WindowStyle Hidden
    }
    for($i=0;$i -lt 40;$i++){
        $count=@(Get-ResidentProcesses).Count
        if($count -eq 1){$script:ResidentSuspended=$false;Write-LabLog "Resident restored to exactly one process." "OK";return}
        Start-Sleep -Milliseconds 250
    }
    throw "Resident restore did not converge to exactly one process."
}

function Add-MediaKeyType {
    if("SpotifyControlMediaKeys" -as [type]){return}
    Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class SpotifyControlMediaKeys {
    [DllImport("user32.dll", SetLastError=true)]
    static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);
    public static void Press(byte vk) {
        keybd_event(vk, 0, 0, UIntPtr.Zero);
        System.Threading.Thread.Sleep(60);
        keybd_event(vk, 0, 2, UIntPtr.Zero);
    }
}
"@
}

function Send-MediaKey {
    param([ValidateSet("PlayPause","Next")][string]$Key)
    Add-MediaKeyType
    if($Key -eq "PlayPause"){[SpotifyControlMediaKeys]::Press([byte]0xB3)}else{[SpotifyControlMediaKeys]::Press([byte]0xB0)}
}

function Test-IsElevated {
    try{
        $id=[Security.Principal.WindowsIdentity]::GetCurrent()
        $principal=New-Object Security.Principal.WindowsPrincipal($id)
        return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    }catch{return $false}
}

function Assert-AcceptedRuntimeBaseline {
    if(Test-IsElevated){throw "Run this profiler as the normal desktop user, not as Administrator."}
    foreach($p in @($MainPath,$AddonPath,$AgentPath,$BootstrapPath,$ConfigPath,$SpotifyExe,$IndexPath)){if(-not(Test-SafePath $p "Leaf")){throw "Required accepted-state file is missing: $p"}}
    $actual=[ordered]@{main=(Get-Sha256Lower $MainPath);addon=(Get-Sha256Lower $AddonPath);agent=(Get-Sha256Lower $AgentPath);bootstrap=(Get-Sha256Lower $BootstrapPath)}
    if($AcceptedMainShas -notcontains $actual.main -or $actual.addon -ne $ExpectedAddonSha -or $actual.agent -ne $ExpectedAgentSha -or $actual.bootstrap -ne $ExpectedBootstrapSha){throw "Spotify Control accepted component hash mismatch. Refusing profiling mutation."}
    $controlVersion=if($actual.main -eq $AcceptedMainShas[1]){'0.6.18'}else{'0.6.17'}
    $spotifyVersion=([string](Get-Item -LiteralPath $SpotifyExe).VersionInfo.ProductVersion).Trim()
    if($spotifyVersion -notmatch ('^'+[regex]::Escape($ExpectedSpotifyVersion)+'(?:\.|$)')){throw "Spotify version drifted from accepted baseline: $spotifyVersion"}
    $sp=Invoke-Native -FilePath (Get-SpicetifyExe) -Arguments @('--version')
    if($sp.ExitCode -ne 0 -or [string]$sp.Output -notmatch [regex]::Escape($ExpectedSpicetifyVersion)){throw "Spicetify version drifted from accepted baseline: $($sp.Output)"}
    try{
        $task=Get-ScheduledTask -TaskName $ResidentTaskName -ErrorAction Stop
        if([string]$task.State -eq 'Disabled'){throw 'Resident task is disabled.'}
        $action=@($task.Actions|Select-Object -First 1)[0]
        if($null -eq $action -or [string]$action.Execute -notmatch '(?i)wscript(?:\.exe)?$' -or [string]$action.Arguments -notmatch [regex]::Escape('spotify-control-agent.vbs')){throw 'Resident task action no longer matches the accepted wscript agent.'}
    }catch{throw ('Accepted resident task precheck failed: '+$_.Exception.Message)}
    if(-not(Wait-ControlWorkersIdle 30)){throw 'Spotify Control maintenance is still active. Refusing to overlap profiling.'}
    return [pscustomobject]@{spotify_control_version=$controlVersion;spotify_version=$spotifyVersion;spicetify_version=$ExpectedSpicetifyVersion;hashes=[pscustomobject]$actual}
}

function Get-RoleSnapshot {
    param([hashtable]$Previous,[double]$IntervalSeconds)
    $procs=@(Get-Process Spotify -ErrorAction SilentlyContinue);$pids=@($procs|Select-Object -ExpandProperty Id|Sort-Object);Update-RoleCache $pids
    $next=@{};$cpu=@{total=0.0;main=0.0;renderer=0.0;gpu=0.0;utility=0.0};$ws=@{total=0L;main=0L;renderer=0L;gpu=0L;utility=0L};$private=0L
    foreach($p in $procs){
        $role="unknown";if($script:RoleCache.ContainsKey([int]$p.Id)){$role=[string]$script:RoleCache[[int]$p.Id]}
        $ws.total += [int64]$p.WorkingSet64;$private += [int64]$p.PrivateMemorySize64
        if($ws.ContainsKey($role)){$ws[$role] += [int64]$p.WorkingSet64}
        if($null -ne $p.CPU){
            $now=[double]$p.CPU;$next[[int]$p.Id]=$now
            if($Previous.ContainsKey([int]$p.Id)){
                $d=$now-[double]$Previous[[int]$p.Id]
                if($d -ge 0){$cpu.total += $d;if($cpu.ContainsKey($role)){$cpu[$role]+=$d}}
            }
        }
    }
    $logical=Get-LogicalCpuCount;$den=[Math]::Max(0.05,$IntervalSeconds)*$logical
    foreach($k in @("total","main","renderer","gpu","utility")){$cpu[$k]=($cpu[$k]/$den)*100.0}
    return [pscustomobject]@{next=$next;count=$procs.Count;cpu=$cpu;ws=$ws;private=$private}
}

function Measure-TransitionCondition {
    param([string]$Label)
    if(-not(Wait-SpotifyReady 20)){throw "Spotify is not running for $Label"}
    $rows=New-Object System.Collections.Generic.List[object]
    $events=New-Object System.Collections.Generic.List[object]
    $prev=@{};foreach($p in @(Get-Process Spotify -ErrorAction SilentlyContinue)){if($null -ne $p.CPU){$prev[[int]$p.Id]=[double]$p.CPU}}
    $clock=[Diagnostics.Stopwatch]::StartNew();$lastSample=0.0;$nextIndex=0
    Write-LabLog "Starting $Label transition phase: $TransitionSeconds sec, interval=${SampleIntervalMs}ms, NEXT offsets=$($NextOffsets -join ',')."
    while($clock.Elapsed.TotalSeconds -lt $TransitionSeconds){
        Start-Sleep -Milliseconds $SampleIntervalMs
        $elapsed=$clock.Elapsed.TotalSeconds;$event=""
        while($nextIndex -lt $NextOffsets.Count -and $elapsed -ge [double]$NextOffsets[$nextIndex]){
            Send-MediaKey "Next";$actual=$clock.Elapsed.TotalSeconds;$event="NEXT_SENT_$($nextIndex+1)"
            $events.Add([pscustomobject]@{index=$nextIndex+1;planned_seconds=[double]$NextOffsets[$nextIndex];actual_seconds=[Math]::Round($actual,3)})
            Write-LabLog ("{0} {1} at +{2}s" -f $Label,$event,[Math]::Round($actual,2))
            $nextIndex++
        }
        $interval=$elapsed-$lastSample;if($interval -le 0){$interval=$SampleIntervalMs/1000.0}
        $snap=Get-RoleSnapshot -Previous $prev -IntervalSeconds $interval;$prev=$snap.next;$lastSample=$elapsed
        $rows.Add([pscustomobject]@{
            timestamp=(Get-Date).ToString("o");condition=$Label;elapsed_seconds=[Math]::Round($elapsed,3);event=$event;process_count=$snap.count
            cpu_percent=[Math]::Round([double]$snap.cpu.total,3);main_cpu_percent=[Math]::Round([double]$snap.cpu.main,3);renderer_cpu_percent=[Math]::Round([double]$snap.cpu.renderer,3);gpu_cpu_percent=[Math]::Round([double]$snap.cpu.gpu,3);utility_cpu_percent=[Math]::Round([double]$snap.cpu.utility,3)
            working_set_mb=[Math]::Round([double]$snap.ws.total/1MB,2);private_mb=[Math]::Round([double]$snap.private/1MB,2);main_working_set_mb=[Math]::Round([double]$snap.ws.main/1MB,2);renderer_working_set_mb=[Math]::Round([double]$snap.ws.renderer/1MB,2);gpu_working_set_mb=[Math]::Round([double]$snap.ws.gpu/1MB,2)
        })
    }
    $clock.Stop()
    if($events.Count -ne $NextOffsets.Count){throw "$Label did not emit all expected NEXT events: $($events.Count)/$($NextOffsets.Count)"}
    Send-MediaKey "PlayPause";Start-Sleep -Seconds 2
    return [pscustomobject]@{rows=$rows.ToArray();events=$events.ToArray()}
}

function Get-MetricSummary {
    param([object[]]$Rows)
    $fields=@("cpu_percent","main_cpu_percent","renderer_cpu_percent","gpu_cpu_percent","utility_cpu_percent","working_set_mb","renderer_working_set_mb","gpu_working_set_mb")
    $o=[ordered]@{}
    foreach($f in $fields){
        $v=@($Rows|ForEach-Object{[double]($_.$f)})
        $o[$f]=[pscustomobject]@{p50=[Math]::Round((Get-Percentile $v 50),2);p95=[Math]::Round((Get-Percentile $v 95),2);p99=[Math]::Round((Get-Percentile $v 99),2);max=[Math]::Round((($v|Measure-Object -Maximum).Maximum),2)}
    }
    return [pscustomobject]$o
}

function Analyze-Transitions {
    param([string]$Label,[object[]]$Rows,[object[]]$Events)
    $windowRows=New-Object System.Collections.Generic.List[object];$peaks=New-Object System.Collections.Generic.List[object]
    foreach($ev in $Events){
        $s=[double]$ev.actual_seconds;$subset=@($Rows|Where-Object{[double]$_.elapsed_seconds -ge $s -and [double]$_.elapsed_seconds -le ($s+$TransitionWindowSeconds)})
        foreach($r in $subset){$windowRows.Add($r)}
        if($subset.Count -eq 0){throw "No transition samples found for $Label event $($ev.index)."}
        $peaks.Add([pscustomobject]@{index=$ev.index;event_seconds=$s;cpu_peak=[Math]::Round((($subset.cpu_percent|Measure-Object -Maximum).Maximum),2);main_peak=[Math]::Round((($subset.main_cpu_percent|Measure-Object -Maximum).Maximum),2);renderer_peak=[Math]::Round((($subset.renderer_cpu_percent|Measure-Object -Maximum).Maximum),2);gpu_peak=[Math]::Round((($subset.gpu_cpu_percent|Measure-Object -Maximum).Maximum),2);ws_peak_mb=[Math]::Round((($subset.working_set_mb|Measure-Object -Maximum).Maximum),1)})
    }
    $active=@($peaks.ToArray()|Where-Object{[double]$_.cpu_peak -ge 1.5}).Count
    return [pscustomobject]@{label=$Label;transition_sample_count=$windowRows.Count;metrics=(Get-MetricSummary $windowRows.ToArray());transitions=$peaks.ToArray();workload_canary_pass=($active -ge 4);active_transition_windows=$active}
}

function Average-TwoMetricSummaries {
    param($A,$B)
    $out=[ordered]@{}
    foreach($f in @("cpu_percent","main_cpu_percent","renderer_cpu_percent","gpu_cpu_percent","utility_cpu_percent","working_set_mb","renderer_working_set_mb","gpu_working_set_mb")){
        $m=[ordered]@{};foreach($k in @("p50","p95","p99","max")){$m[$k]=[Math]::Round((([double]$A.$f.$k+[double]$B.$f.$k)/2.0),2)};$out[$f]=[pscustomobject]$m
    }
    return [pscustomobject]$out
}

function Build-Comparison {
    param($Baseline,$Condition)
    return [pscustomobject]@{
        label=$Condition.label
        cpu_p95_saved=[Math]::Round([double]$Baseline.cpu_percent.p95-[double]$Condition.metrics.cpu_percent.p95,2)
        cpu_p99_saved=[Math]::Round([double]$Baseline.cpu_percent.p99-[double]$Condition.metrics.cpu_percent.p99,2)
        cpu_max_saved=[Math]::Round([double]$Baseline.cpu_percent.max-[double]$Condition.metrics.cpu_percent.max,2)
        renderer_p95_saved=[Math]::Round([double]$Baseline.renderer_cpu_percent.p95-[double]$Condition.metrics.renderer_cpu_percent.p95,2)
        renderer_max_saved=[Math]::Round([double]$Baseline.renderer_cpu_percent.max-[double]$Condition.metrics.renderer_cpu_percent.max,2)
        gpu_p95_saved=[Math]::Round([double]$Baseline.gpu_cpu_percent.p95-[double]$Condition.metrics.gpu_cpu_percent.p95,2)
        working_set_p95_saved_mb=[Math]::Round([double]$Baseline.working_set_mb.p95-[double]$Condition.metrics.working_set_mb.p95,1)
    }
}

function Build-TextReport {
    param($Report)
    $l=New-Object System.Collections.Generic.List[string]
    $l.Add("Spotify Control Track Transition Single-Hook Isolation Report v$Version");$l.Add("Generated: $($Report.generated_at)");$l.Add("")
    $l.Add("Accepted runtime: Spotify Control $($Report.accepted_baseline.spotify_control_version) / Addon Manager 0.6.5-r7 / Spotify $($Report.accepted_baseline.spotify_version) / Spicetify $($Report.accepted_baseline.spicetify_version)")
    $l.Add("CPU/renderer baseline confidence: $($Report.baseline_cpu_confidence)");$l.Add(("Baseline A/B transition p95 drift: CPU={0} pts | renderer={1} pts" -f $Report.baseline_drift.cpu_p95_points,$Report.baseline_drift.renderer_p95_points))
    $l.Add("Memory baseline confidence: $($Report.baseline_memory_confidence)");$l.Add(("Baseline A/B WS p95 drift: {0} MB (memory ranking is secondary)" -f $Report.baseline_drift.ws_p95_mb));$l.Add("")
    foreach($c in @($Report.conditions)){
        $m=$c.metrics;$l.Add($c.label);$l.Add(("  CPU p50={0}% p95={1}% p99={2}% max={3}%" -f $m.cpu_percent.p50,$m.cpu_percent.p95,$m.cpu_percent.p99,$m.cpu_percent.max));$l.Add(("  Renderer p95={0}% max={1}% | GPU p95={2}% max={3}% | WS p95={4} MB" -f $m.renderer_cpu_percent.p95,$m.renderer_cpu_percent.max,$m.gpu_cpu_percent.p95,$m.gpu_cpu_percent.max,$m.working_set_mb.p95));$l.Add("")
    }
    $l.Add("Ranked single-hook savings vs averaged BASELINE_A/B (positive = disabling only that hook reduced transition cost):")
    foreach($x in @($Report.single_hook_ranking)){$l.Add(("  {0}: CPU p95 {1} pts | p99 {2} | max {3} | renderer p95 {4} | target {5}" -f $x.label,$x.cpu_p95_saved,$x.cpu_p99_saved,$x.cpu_max_saved,$x.renderer_p95_saved,$x.target_src))}
    if(@($Report.combined_comparisons).Count -gt 0){$l.Add("");$l.Add("Combined interaction checks:");foreach($x in @($Report.combined_comparisons)){$l.Add(("  {0}: CPU p95 {1} pts | p99 {2} | max {3} | renderer p95 {4}" -f $x.label,$x.cpu_p95_saved,$x.cpu_p99_saved,$x.cpu_max_saved,$x.renderer_p95_saved))}}
    $l.Add("");$l.Add("Protected/unknown hooks deliberately left active:");foreach($x in @($Report.protected_or_unknown_hooks)){$l.Add("  "+$x)}
    $l.Add("");$l.Add("Safety:");$l.Add(("- Startup residual Spotify processes auto-closed before xpui mutation: {0}" -f $Report.preflight_spotify_processes_autoclosed));$l.Add("- Spicetify backup/apply/restore and config mutation were never invoked.");$l.Add("- Each SINGLE_* condition removes exactly one allowlisted script/theme/userCSS tag from active xpui/index.html; protected and unknown hooks remain active.");$l.Add("- PRESENTATION_HOOKS_OFF, when present, removes only theme.js + userCSS link tags together; Spicetify core/preprocesses remain.");$l.Add("- No extension/CustomApp payload file or lazy route chunk was deleted or renamed.");$l.Add("- Browser/Default Spotify WebView persistence was safety-backed up and never edited.");$l.Add("- ivLyrics/Tagify/splitify/unknown hooks were preserved.");$l.Add("- Resident production code/task definition was not changed; only its running process was temporarily suspended to avoid measurement contamination.");$l.Add("- Original index.html was restored byte-for-byte and the complete xpui tree fingerprint was verified before exit.");$l.Add("- config-xpui.ini remained byte-for-byte unchanged throughout the run.")
    return ($l -join [Environment]::NewLine)
}

function Invoke-SelfTest {
    $vals=@();for($i=1;$i -le 100;$i++){$vals+=[double]$i}
    if((Get-Percentile $vals 95) -ne 95){throw 'Percentile self-test failed.'}
    if((Get-Median @(1.0,2.0,3.0,4.0)) -ne 2.5){throw 'Median self-test failed.'}
    if((Get-ProcessRoleFromCommandLine 'spotify.exe --type=renderer --foo') -ne 'renderer'){throw 'Renderer classifier failed.'}
    $html="<!doctype html>`r`n<link rel='stylesheet' class='userCSS' href='colors.css'>`r`n<link rel='stylesheet' class='userCSS' href='user.css'>`r`n<body>`r`n<script defer src='extensions/bookmark.js'></script>`r`n<script defer src='extensions/sc-star-ratings.js'></script>`r`n<script defer src='extensions/theme.js'></script>`r`n<script defer src='extensions/better-local-files/hook.js'></script>`r`n<script defer src='extensions/marketplace/hook.js'></script>`r`n<script defer src='extensions/ivLyrics/protected.js'></script>`r`n<script defer src='extensions/mystery.js'></script>`r`n</body>`r`n"
    $bytes=ConvertTo-Utf8BytesPreserveBom -Text $html -Bom $true
    $inv=Get-IndexHookInventoryFromBytes -Bytes $bytes -ConfiguredExtensions @('bookmark.js','sc-star-ratings.js','mystery.js') -ConfiguredApps @('better-local-files','marketplace','ivLyrics')
    if($inv.scripts.Count -ne 7 -or $inv.styles.Count -ne 2){throw 'Hook inventory fixture failed.'}
    $built=Build-SingleHookVariantMatrix -Inventory $inv -Extensions @('bookmark.js','sc-star-ratings.js','mystery.js') -Apps @('better-local-files','marketplace','ivLyrics')
    $matrix=@($built.variants);$singles=@($matrix|Where-Object{$_.label -like 'SINGLE_*'})
    if($singles.Count -ne 7){throw ('Single-hook matrix fixture count failed: '+$singles.Count)}
    foreach($v in $singles){if(@($v.remove_tags).Count -ne 1){throw ('Single-hook variant removed !=1 tag: '+$v.label)}}
    $presentation=@($matrix|Where-Object label -eq 'PRESENTATION_HOOKS_OFF')[0];if($null -eq $presentation -or @($presentation.remove_tags).Count -ne 3){throw 'Presentation interaction fixture failed.'}
    if($built.protected_or_unknown_hooks -notcontains 'extensions/ivLyrics/protected.js' -or $built.protected_or_unknown_hooks -notcontains 'extensions/mystery.js'){throw 'Protected/unknown residual fixture failed.'}
    $allRemoved=@($matrix|ForEach-Object{@($_.remove_tags)});foreach($protected in @('extensions/ivLyrics/protected.js','extensions/mystery.js')){foreach($tag in @($inv.scripts|Where-Object src -eq $protected|ForEach-Object tag)){if($allRemoved -contains $tag){throw ('Protected/unknown hook entered mutation matrix: '+$protected)}}}
    $decoded=ConvertFrom-Utf8BytesStrict $bytes;if(-not $decoded.bom -or [string]$decoded.text -notmatch "`r`n"){throw 'UTF-8 BOM/CRLF fixture failed.'}
    $tmp=Join-Path ([IO.Path]::GetTempPath()) ('spotify-control-perf-selftest-'+[Guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Force -Path $tmp|Out-Null
    try{
        $root=Join-Path $tmp 'xpui';New-Item -ItemType Directory -Force -Path $root|Out-Null;$idx=Join-Path $root 'index.html';[IO.File]::WriteAllBytes($idx,$bytes);$orig=Get-Sha256Lower $idx;$tree1=Get-TreeFingerprint $root
        $text=[string]$decoded.text;foreach($tag in @($presentation.remove_tags)){$text=$text.Replace([string]$tag,'')};$mut=ConvertTo-Utf8BytesPreserveBom -Text $text -Bom $true;[IO.File]::WriteAllBytes($idx,$mut);if((Get-Sha256Lower $idx)-eq $orig){throw 'Synthetic variant did not change index.'};[IO.File]::WriteAllBytes($idx,$bytes);if((Get-Sha256Lower $idx)-ne $orig){throw 'Synthetic exact index restore failed.'};$tree2=Get-TreeFingerprint $root;if($tree1.sha256 -ne $tree2.sha256){throw 'Synthetic full-tree restore failed.'}
        $rows=@();for($i=0;$i -le 80;$i++){$e=$i/4.0;$cpu=1.0;if(($e-ge 5 -and $e-le 11)-or($e-ge 15 -and $e-le 21)){$cpu=10.0};$rows+=[pscustomobject]@{elapsed_seconds=$e;cpu_percent=$cpu;main_cpu_percent=$cpu;renderer_cpu_percent=0;gpu_cpu_percent=0;utility_cpu_percent=0;working_set_mb=100;renderer_working_set_mb=40;gpu_working_set_mb=10}}
        $ev=@([pscustomobject]@{index=1;actual_seconds=5.0},[pscustomobject]@{index=2;actual_seconds=15.0});$a=Analyze-Transitions -Label 'SYNTH' -Rows $rows -Events $ev;if($a.transitions.Count-ne2 -or [double]$a.metrics.cpu_percent.max-ne10.0){throw 'Transition window extraction self-test failed.'}

        # Exercise the real atomic index swap + real Restore-OriginalXpui through an injected failure, entirely in the temp tree.
        $cfg=Join-Path $tmp 'config-xpui.ini';[IO.File]::WriteAllText($cfg,"[AdditionalOptions]`r`nextensions = bookmark.js`r`n",[Text.UTF8Encoding]::new($true));$bak=Join-Path $tmp 'index.original.html';[IO.File]::WriteAllBytes($bak,$bytes)
        $script:IndexPath=$idx;$script:XpuiRoot=$root;$script:ConfigPath=$cfg;$script:OriginalIndexBackup=$bak;$script:OriginalIndexHash=$orig;$script:OriginalXpuiTree=$tree1;$script:OriginalConfigHash=Get-Sha256Lower $cfg;$script:XpuiRestored=$false;$script:XpuiMutationStarted=$false
        $one=@($singles|Where-Object{$_.target_src -eq 'extensions/bookmark.js'})[0];if($null -eq $one){throw 'Failure-injection fixture target missing.'}
        [void](Write-IndexVariantAtomic $one)
        try{throw 'SYNTHETIC_RESTORE_FAILURE_INJECTION'}catch{if($_.Exception.Message -ne 'SYNTHETIC_RESTORE_FAILURE_INJECTION'){throw};Restore-OriginalXpui}
        if((Get-Sha256Lower $idx)-ne $orig){throw 'Failure injection did not restore original index exactly.'};$tree3=Get-TreeFingerprint $root;if($tree3.sha256 -ne $tree1.sha256){throw 'Failure injection did not restore full xpui tree exactly.'};if((Get-Sha256Lower $cfg)-ne $script:OriginalConfigHash){throw 'Failure injection changed config.'}
        Write-Host 'SELFTEST PASS: synthetic failure injection restored exact index/tree/config via production restore function.'
    }finally{Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue}
    if($env:SPOTIFYCONTROL_TEST_RESIDUAL_CLEANUP -eq '1'){
        $fakeRoot=Join-Path ([IO.Path]::GetTempPath()) ('spotify-control-residual-selftest-'+[Guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Force -Path $fakeRoot|Out-Null
        try{
            $fakeExe=Join-Path $fakeRoot 'Spotify.exe';Copy-Item -LiteralPath (Join-Path $PSHOME 'powershell.exe') -Destination $fakeExe -Force
            $fake=Start-Process -FilePath $fakeExe -ArgumentList @('-NoProfile','-Command','Start-Sleep -Seconds 60') -PassThru
            Start-Sleep -Milliseconds 500
            if(@(Get-Process Spotify -ErrorAction SilentlyContinue).Count -lt 1){throw 'Residual Spotify cleanup fixture could not create a Spotify-named process.'}
            Stop-SpotifyForVariant
            if(@(Get-Process Spotify -ErrorAction SilentlyContinue).Count -ne 0){throw 'Residual Spotify cleanup fixture left a Spotify-named process running.'}
            Write-Host 'SELFTEST PASS: residual Spotify process cleanup before xpui mutation.'
        }finally{
            @(Get-Process Spotify -ErrorAction SilentlyContinue)|Where-Object{$_.Path -eq $fakeExe}|Stop-Process -Force -ErrorAction SilentlyContinue
            Remove-Item -LiteralPath $fakeRoot -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
    Write-LabLog "Track transition single-hook isolation v$Version direct-xpui self-test passed; production paths were not mutated." 'OK'
    Write-Host 'SELFTEST PASS: single-hook hook inventory/matrix, UTF-8 BOM+CRLF preservation, exact tree restore, failure injection, percentile/process/transition math.'
}

function Show-Status {
    Write-Host "";Write-Host "Spotify Control Track Transition Single-Hook Isolation v$Version" -ForegroundColor Cyan
    if(Test-SafePath $LatestTxt "Leaf"){Get-Content -LiteralPath $LatestTxt;Write-Host "";Write-Host ("JSON: "+$LatestJson);Write-Host ("CSV:  "+$LatestCsv)}else{Write-Host "No Phase-2 result yet."}
}

function Invoke-Lab {
    if($SampleIntervalMs -lt 200 -or $SampleIntervalMs -gt 1000){throw 'SampleIntervalMs must be 200..1000.'}
    if($TransitionSeconds -lt 85){throw 'TransitionSeconds must be at least 85 to cover all five NEXT events.'}
    $accepted=Assert-AcceptedRuntimeBaseline
    Suspend-Resident
    if(-not(Wait-ControlWorkersIdle 10)){throw 'A Spotify Control worker became active after resident suspension.'}
    $preflightSpotifyCount=@(Get-Process Spotify -ErrorAction SilentlyContinue).Count
    if($preflightSpotifyCount -gt 0){
        Write-LabLog ("Detected {0} residual Spotify process(es) after accepted-state checks; closing them before any xpui mutation." -f $preflightSpotifyCount) 'WARN'
        Stop-SpotifyForVariant
        if(@(Get-Process Spotify -ErrorAction SilentlyContinue).Count -gt 0){throw 'Residual Spotify process cleanup failed before xpui mutation.'}
        Write-LabLog 'Residual Spotify processes closed before any xpui mutation.' 'OK'
    }

    $stamp=Get-Date -Format 'yyyyMMdd-HHmmss';$script:Session=Join-Path $BackupRoot $stamp;New-Item -ItemType Directory -Force -Path $script:Session|Out-Null
    $script:OriginalConfigHash=Get-Sha256Lower $ConfigPath
    $script:OriginalExtensions=@(Get-IniList -Path $ConfigPath -Section 'AdditionalOptions' -Key 'extensions')
    $script:OriginalApps=@(Get-IniList -Path $ConfigPath -Section 'AdditionalOptions' -Key 'custom_apps')
    $script:OriginalIndexBackup=Join-Path $script:Session 'xpui-index.original.html';Copy-Item -LiteralPath $IndexPath -Destination $script:OriginalIndexBackup -Force;$script:OriginalIndexHash=Get-Sha256Lower $IndexPath
    $script:OriginalXpuiTree=Get-TreeFingerprint $XpuiRoot
    $script:HookInventory=Get-IndexHookInventoryFromBytes -Bytes ([IO.File]::ReadAllBytes($IndexPath)) -ConfiguredExtensions $script:OriginalExtensions -ConfiguredApps $script:OriginalApps
    $script:PersistenceBackup=Backup-ProtectedPersistence (Join-Path $script:Session 'protected-persistence')
    $built=Build-SingleHookVariantMatrix -Inventory $script:HookInventory -Extensions $script:OriginalExtensions -Apps $script:OriginalApps
    $variants=@($built.variants);$variantCount=$variants.Count;$singleCount=@($variants|Where-Object{$_.label -like 'SINGLE_*'}).Count
    if($singleCount -lt 1){throw 'No allowlisted safe single hooks were found in active xpui; refusing a meaningless run.'}

    Write-Host '';Write-Host "Spotify Control Track Transition Single-Hook Isolation v$Version" -ForegroundColor Cyan;Write-Host '-----------------------------------------------------------'
    Write-Host ("One integrated run: {0} conditions x 5 automatic NEXT transitions ({1} single-hook conditions)." -f $variantCount,$singleCount);Write-Host 'No spicetify apply/backup/config mutation is used.' -ForegroundColor Green
    Write-Host 'Do not touch Spotify until the profiler finishes.' -ForegroundColor Yellow;Write-Host 'The resident is temporarily suspended and will be restored automatically.' -ForegroundColor Yellow;Write-Host ''

    $raw=New-Object System.Collections.Generic.List[object];$analyses=New-Object System.Collections.Generic.List[object];$mutations=New-Object System.Collections.Generic.List[object]
    foreach($v in $variants){
        Write-Host ("[{0}/{1}] {2}" -f ($analyses.Count+1),$variantCount,$v.label) -ForegroundColor Cyan
        $mut=Prepare-Variant $v;$mutations.Add([pscustomobject]@{label=$v.label;removed_hooks=$mut.removed_count;index_sha256=$mut.index_sha256;definition=$v.definition;category=$v.category;target_src=$v.target_src;target_kind=$v.target_kind;target_owner=$v.target_owner})
        if($v.label -like 'SINGLE_*' -and [int]$mut.removed_count -ne 1){throw "$($v.label) must remove exactly one hook; removed $($mut.removed_count)."}
        $m=Measure-TransitionCondition -Label $v.label
        foreach($r in $m.rows){$raw.Add($r)}
        $a=Analyze-Transitions -Label $v.label -Rows $m.rows -Events $m.events
        if(-not $a.workload_canary_pass){throw "$($v.label) transition workload canary failed: only $($a.active_transition_windows)/5 windows reached 1.5% CPU. Playback/NEXT context may not be active."}
        $analyses.Add($a)
        Write-LabLog ("Completed {0}: CPU p95={1}% p99={2}% max={3}% renderer p95={4}%" -f $v.label,$a.metrics.cpu_percent.p95,$a.metrics.cpu_percent.p99,$a.metrics.cpu_percent.max,$a.metrics.renderer_cpu_percent.p95) 'OK'
    }
    Stop-SpotifyForVariant
    Restore-OriginalXpui

    $a0=@($analyses|Where-Object label -eq 'BASELINE_A')[0];$b0=@($analyses|Where-Object label -eq 'BASELINE_B')[0];$base=Average-TwoMetricSummaries $a0.metrics $b0.metrics
    $drift=[pscustomobject]@{cpu_p95_points=[Math]::Round([Math]::Abs([double]$a0.metrics.cpu_percent.p95-[double]$b0.metrics.cpu_percent.p95),2);cpu_p99_points=[Math]::Round([Math]::Abs([double]$a0.metrics.cpu_percent.p99-[double]$b0.metrics.cpu_percent.p99),2);renderer_p95_points=[Math]::Round([Math]::Abs([double]$a0.metrics.renderer_cpu_percent.p95-[double]$b0.metrics.renderer_cpu_percent.p95),2);ws_p95_mb=[Math]::Round([Math]::Abs([double]$a0.metrics.working_set_mb.p95-[double]$b0.metrics.working_set_mb.p95),1)}
    $cpuConfidence='high';if($drift.cpu_p95_points -gt 8 -or $drift.renderer_p95_points -gt 6){$cpuConfidence='low'}elseif($drift.cpu_p95_points -gt 4 -or $drift.renderer_p95_points -gt 3){$cpuConfidence='medium'}
    $memoryConfidence='high';if($drift.ws_p95_mb -gt 180){$memoryConfidence='low'}elseif($drift.ws_p95_mb -gt 100){$memoryConfidence='medium'}
    $comparisons=New-Object System.Collections.Generic.List[object]
    foreach($a in @($analyses|Where-Object{$_.label -notmatch '^BASELINE_'})){
        $x=Build-Comparison $base $a;$mut=@($mutations|Where-Object label -eq $a.label)[0]
        $comparisons.Add([pscustomobject]@{label=$x.label;cpu_p95_saved=$x.cpu_p95_saved;cpu_p99_saved=$x.cpu_p99_saved;cpu_max_saved=$x.cpu_max_saved;renderer_p95_saved=$x.renderer_p95_saved;renderer_max_saved=$x.renderer_max_saved;gpu_p95_saved=$x.gpu_p95_saved;working_set_p95_saved_mb=$x.working_set_p95_saved_mb;category=$mut.category;target_src=$mut.target_src;target_kind=$mut.target_kind;target_owner=$mut.target_owner})
    }
    $singleRanking=@($comparisons.ToArray()|Where-Object{$_.label -like 'SINGLE_*'}|Sort-Object @{Expression='cpu_p95_saved';Descending=$true},@{Expression='renderer_p95_saved';Descending=$true})
    $combined=@($comparisons.ToArray()|Where-Object{$_.label -notlike 'SINGLE_*'})

    $report=[pscustomobject]@{
        version=$Version;generated_at=(Get-Date).ToString('o');verified_run=$true;accepted_baseline=$accepted;preflight_spotify_processes_autoclosed=$preflightSpotifyCount;sample_interval_ms=$SampleIntervalMs;transition_window_seconds=$TransitionWindowSeconds;next_offsets_seconds=$NextOffsets
        original_extensions=$script:OriginalExtensions;original_custom_apps=$script:OriginalApps;protected_apps=$ProtectedAppNames;persistence_backup=$script:PersistenceBackup;session=$script:Session
        mutation_engine='direct-active-xpui-single-hook-index-tags';spicetify_apply_used=$false;spicetify_config_mutated=$false;xpui_root=$XpuiRoot;original_index_sha256=$script:OriginalIndexHash;original_xpui_tree=$script:OriginalXpuiTree
        hook_inventory=[pscustomobject]@{scripts=@($script:HookInventory.scripts|ForEach-Object{$_.src});user_css=@($script:HookInventory.styles|ForEach-Object{$_.href})};known_script_hooks=$built.known_script_hooks;protected_or_unknown_hooks=$built.protected_or_unknown_hooks;presentation_tag_count=$built.presentation_tag_count;variant_mutations=$mutations.ToArray()
        baseline_average=$base;baseline_drift=$drift;baseline_cpu_confidence=$cpuConfidence;baseline_memory_confidence=$memoryConfidence;baseline_confidence=$cpuConfidence;conditions=$analyses.ToArray();comparisons=$comparisons.ToArray();single_hook_ranking=$singleRanking;combined_comparisons=$combined
        config_unchanged_exact=((Get-Sha256Lower $ConfigPath)-eq $script:OriginalConfigHash);index_restored_exact=((Get-Sha256Lower $IndexPath)-eq $script:OriginalIndexHash);xpui_tree_restored_exact=((Get-TreeFingerprint $XpuiRoot).sha256 -eq $script:OriginalXpuiTree.sha256);resident_process_count_after=$null;workload_canary='at least 4/5 NEXT windows >= 1.5% total machine CPU per condition; media-key injection is verified, track metadata is not read'
    }
    $text=Build-TextReport $report
    $sessionJson=Join-Path $script:Session 'track-transition-single-hook.json';$sessionTxt=Join-Path $script:Session 'track-transition-single-hook.txt';$sessionCsv=Join-Path $script:Session 'track-transition-single-hook-raw.csv'
    $report|ConvertTo-Json -Depth 20|Set-Content -LiteralPath $sessionJson -Encoding UTF8;$text|Set-Content -LiteralPath $sessionTxt -Encoding UTF8;$raw.ToArray()|Export-Csv -LiteralPath $sessionCsv -NoTypeInformation -Encoding UTF8
    Copy-Item $sessionJson $LatestJson -Force;Copy-Item $sessionTxt $LatestTxt -Force;Copy-Item $sessionCsv $LatestCsv -Force
    Restore-Resident;$report.resident_process_count_after=@(Get-ResidentProcesses).Count;$report|ConvertTo-Json -Depth 20|Set-Content -LiteralPath $sessionJson -Encoding UTF8;Copy-Item $sessionJson $LatestJson -Force
    Write-Host '';Write-Host 'TRACK TRANSITION SINGLE-HOOK ISOLATION VERIFIED' -ForegroundColor Green;Write-Host $text;Write-Host '';Write-Host ('Report: '+$LatestTxt) -ForegroundColor Cyan;Write-Host ('JSON:   '+$LatestJson);Write-Host ('CSV:    '+$LatestCsv)
}

try{
    switch($Action){"Run"{Invoke-Lab};"Status"{Show-Status};"SelfTest"{Invoke-SelfTest}}
    exit 0
}catch{
    Write-LabLog $_.Exception.Message "ERROR"
    if($Action -ne "SelfTest"){($_|Out-String)|Set-Content -LiteralPath (Join-Path $LogRoot "track-transition-single-hook-error.log") -Encoding UTF8}
    $restoreErrors=New-Object System.Collections.Generic.List[string]
    if($script:XpuiMutationStarted -and -not $script:XpuiRestored){try{Stop-SpotifyForVariant;Restore-OriginalXpui}catch{$restoreErrors.Add("xpui: "+$_.Exception.Message)}}
    if($script:ResidentWasRunning){try{Restore-Resident}catch{$restoreErrors.Add("resident: "+$_.Exception.Message)}}
    Write-Host "";Write-Host "TRACK TRANSITION SINGLE-HOOK ISOLATION FAILED" -ForegroundColor Red
    if($restoreErrors.Count -eq 0){Write-Host "Safety restore completed. Do not rerun this package; send the console output/error log." -ForegroundColor Yellow}else{Write-Host ("Safety restore errors: "+($restoreErrors -join " | ")) -ForegroundColor Red}
    if($Action -ne "SelfTest"){Write-Host ("Log: "+(Join-Path $LogRoot "track-transition-single-hook-error.log"))};exit 1
}
