@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0track-transition-isolation.ps1" -Action SelfTest
set EXITCODE=%ERRORLEVEL%
echo.
pause
exit /b %EXITCODE%
