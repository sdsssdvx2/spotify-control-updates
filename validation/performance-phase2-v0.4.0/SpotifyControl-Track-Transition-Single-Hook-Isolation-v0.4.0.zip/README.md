Spotify Control Track Transition Single-Hook Isolation v0.4.0
================================================================

Purpose
-------
This is the next Performance Phase-2 cause-isolation package derived from the already Windows-validated v0.3.2 direct-xpui profiler.
It does NOT repeat the completed idle, paused-vs-playing, group-level hook, ALL_KNOWN_HOOKS_OFF, or NEAR_CORE experiments.
Instead, it turns off each allowlisted safe always-loaded hook one at a time so the transition-spike contributor can be ranked directly.

Accepted Spotify Control baseline
---------------------------------
- Spotify Control exact v0.6.17 OR v0.6.18 main payload
- Addon Manager v0.6.5-r7 exact
- resident agent v0.1.1 exact
- Bootstrap v1.0.6 exact
- Spotify 1.3.6.1921
- Spicetify 2.46.2

v0.4.0 still never calls Spicetify apply, backup, restore, auto, or config mutation. It works only on the already-applied active xpui index and restores the original bytes/tree before exit.

Before running
--------------
1. In Spotify choose a normal playlist or album with at least 8 playable tracks.
2. Pause on a normal track.
3. Exit Spotify normally. If residual tray/helper Spotify processes remain, v0.4.0 suspends the accepted Spotify Control resident first and closes those processes before any xpui mutation.
4. Extract this ZIP to a new folder.
5. Run RUN_TRACK_TRANSITION_ISOLATION.cmd normally, NOT as Administrator.
6. Once it starts, do not touch Spotify until the run finishes.

What it measures
----------------
The matrix is built from the active xpui/index.html and current config at runtime.
- BASELINE_A
- one SINGLE_* condition for every present allowlisted safe direct-extension script hook
- one SINGLE_* condition for every present allowlisted optional custom-app/Marketplace background extension_files hook
- one SINGLE_THEME_* condition for every present theme.js tag
- one SINGLE_USERCSS_* condition for every present userCSS link tag
- PRESENTATION_HOOKS_OFF only when more than one theme/userCSS presentation tag exists, to measure interaction between those presentation hooks
- BASELINE_B

Every SINGLE_* condition must remove exactly one tag or the run fails closed. ivLyrics, Tagify, Splitify, unknown hooks, Spicetify core/preprocesses, lazy custom-app routes, and all extension/CustomApp payload files remain untouched.

Interpretation
--------------
The text/JSON report ranks SINGLE_* conditions by CPU p95 savings versus the averaged BASELINE_A/B. Renderer p95 is the main secondary signal.
CPU/renderer baseline confidence is now judged separately from working-set drift, because the completed v0.3.2 run had only 0.74 CPU-p95 points and 1.1 renderer-p95 points of baseline drift but 336.8 MB of working-set drift. Memory remains reported but is treated as secondary when its baseline confidence is low.

Safety model
------------
- accepted component hashes/versions are verified before mutation
- Spotify Control resident is suspended before residual Spotify cleanup
- config-xpui.ini is read-only and must finish byte-for-byte unchanged
- Spicetify apply/backup/restore/config mutation is never invoked
- only active Spotify Apps/xpui/index.html is changed temporarily
- each condition starts from exact original index bytes
- no extension/CustomApp payload, lazy route, Browser/Default persistence, login/settings, Marketplace data, Star Ratings, Tagify data, or ivLyrics payload is deleted, renamed, reset, or reinstalled
- Browser/Default IndexedDB/Local Storage/Session Storage/WebStorage/Preferences get a safety backup and are never edited
- normal and failure paths restore original index.html byte-for-byte and verify the complete xpui tree fingerprint
- the accepted resident task/code is not modified and is restored to exactly one process

Output
------
On success the console ends with:
  TRACK TRANSITION SINGLE-HOOK ISOLATION VERIFIED

Reports:
  %LOCALAPPDATA%\SpotifyControl\reports\track-transition-single-hook-latest.json
  %LOCALAPPDATA%\SpotifyControl\reports\track-transition-single-hook-latest.txt
  %LOCALAPPDATA%\SpotifyControl\reports\track-transition-single-hook-raw-latest.csv

The existing v0.3.2 track-transition-isolation-latest.* files are not overwritten.

On failure, do NOT rerun this package. Send the console output and:
  %LOCALAPPDATA%\SpotifyControl\logs\track-transition-single-hook-error.log
