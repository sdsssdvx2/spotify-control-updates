@echo off
setlocal
cd /d "%~dp0"
echo Spotify Control Track Transition Single-Hook Isolation v0.4.0
echo -------------------------------------------------------------
echo.
echo IMPORTANT:
echo   1. In Spotify, choose a playlist/album with at least 8 playable tracks.
echo   2. PAUSE playback on a normal track, then EXIT Spotify normally.
echo      If tray/helper processes remain, v0.4.0 closes them safely before xpui mutation.
echo   3. Run this file normally, NOT as Administrator.
echo   4. After this starts, do not touch Spotify until it finishes.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0track-transition-isolation.ps1" -Action Run
set EXITCODE=%ERRORLEVEL%
if not "%EXITCODE%"=="0" (
  echo.
  echo Phase-2 single-hook profiling failed with exit code %EXITCODE%.
  echo Do NOT rerun this package. Send the console output/error log for review.
)
echo.
pause
exit /b %EXITCODE%
